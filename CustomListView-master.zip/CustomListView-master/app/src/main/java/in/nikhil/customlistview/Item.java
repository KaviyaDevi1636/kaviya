package in.nikhil.customlistview;

class Item {
    String Heading;
    String SubHeading;
}
