Android Custom ListView with Base Adapter 


<p>
<img src="screens/customListView.gif" height="600" width="300" />
</p>

Find Documentation here -
https://medium.com/@coolnikhilmaurya/listview-with-baseadapter-5480f2506870
